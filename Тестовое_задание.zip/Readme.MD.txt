Запустить Приложение.exe
Kjdbnm rjnf